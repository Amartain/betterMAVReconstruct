import oracledb
import gui
import hashlib
from tkinter import messagebox as MessageBox, messagebox
import searchWindow as sw

def userMod():
    email = gui.userEmailEntry.get()
    password = gui.userPasswordEntry.get()
    hashedPassword = hashlib.sha256(password.encode()).hexdigest()
    password = hashedPassword

    dsn = oracledb.makedsn("localhost", 1521, service_name="xe")
    db = oracledb.connect(user="MATT", password="matt", dsn=dsn)

    cursor = db.cursor()
    try:
        cursor.execute('update felhasznalok set jelszo=:s  where email=:s', (password, email,))
        db.commit()
        MessageBox.showinfo("Done", "Felhasználó módosítva")

    except:
        MessageBox.showinfo("Hiba", "Ez nem jött be")

    cursor.close()


def userDelete():
    email = gui.userEmailEntry.get()

    dsn = oracledb.makedsn("localhost", 1521, service_name="xe")
    db = oracledb.connect(user="MATT", password="matt", dsn=dsn)

    cursor = db.cursor()
    try:
        cursor.execute('delete from felhasznalok where email=:s', (email,))
        db.commit()
        MessageBox.showinfo("Done", "Felhasználó törölve")

    except oracledb.Error as err:
        MessageBox.showinfo("Hiba", "Ez nem jött be és a következő a hiba: {}".format(err))

    cursor.close()

def login():
    email = gui.login_id_entry.get()
    jelszo = gui.login_password_entry.get()
    if email[len(email)-1] == ";":
        messagebox.showinfo("NOPE", "Try again sweaty!")

    jelszo_hash = hashlib.sha3_256(jelszo.encode()).hexdigest()
    jelszo = jelszo_hash

    #A user-t meg a jelszo-t sajátra köll átállítani hogy működjön
    dsn = oracledb.makedsn("localhost", 1521, service_name="xe")
    db = oracledb.connect(user="MATT", password="matt", dsn=dsn)

    cursor = db.cursor()
    try:
        cursor.execute("SELECT * FROM felhasznalok WHERE email = :s", (email,))
        result = cursor.fetchone()

        if result is None:
            MessageBox.showinfo("Hiba", "Nincs ilyen ceges_ID!")
        elif result[2] != jelszo:
            MessageBox.showinfo("Hiba", "Hibás jelszó!")
        else:
            global Email
            Email = result[0]
            if result[1] == 'admin':
                MessageBox.showinfo("Info", "Üdvözöljük {} adminunk!".format(result[1]))
                global felhasznalo_email
                gui.open_admin_options()
            else:
                MessageBox.showinfo("Info", "Üdvözöljük {}!".format(result[1]))
                sw.openSearchwindow()
    except oracledb.Error as err:
        MessageBox.showinfo("Hiba", "Hiba történt a belépés során: {}".format(err))

    db.close()


def register():
    nev = gui.name_entry.get()
    jelszo = gui.password_entry.get()
    jelszo_megerosites = gui.password_confirm_entry.get()
    email = gui.email_entry.get()
    tipus = gui.tipus_entry.get()

    if email[len(email)-1] == ";":
        messagebox.showinfo("NOPE", "Try again sweaty!")

    if not (nev and jelszo and email):
        MessageBox.showinfo("Hiba", "Minden mező kitöltése kötelező!")
        return

    if jelszo != jelszo_megerosites:
        MessageBox.showinfo("Hiba", "A jelszavak nem egyeznek!")
        return

    jelszo_hash = hashlib.sha3_256(jelszo.encode()).hexdigest()
    jelszo = jelszo_hash
    gui.password_entry.delete(0, 'end')
    gui.password_confirm_entry.delete(0, 'end')
    jelszo_megerosites = ""

    dsn = oracledb.makedsn("localhost", 1521, service_name="xe")
    db = oracledb.connect(user="MATT", password="matt", dsn=dsn)
    
    cursor = db.cursor()

    try:
        cursor.execute(
            "INSERT INTO Felhasznalok (email, nev, jelszo, utastipus) VALUES (:s, :s, :s, :s)",
            (email, nev, jelszo, tipus))
        db.commit()
        MessageBox.showinfo("Siker", "Sikeres regisztráció!")
        gui.reg_window.destroy()
        MessageBox.showinfo("Siker", "A ceges_ID: {}".format(email))
    except oracledb.Error as err:
        MessageBox.showinfo("Hiba", "Hiba történt a regisztráció során: {}".format(err))
        db.rollback()

    db.close()